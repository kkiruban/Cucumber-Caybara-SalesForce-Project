#Step definition to verify field not present over the page
Then(/^I should not see the field "([^"]*)" over the page$/) do |field_name|
  begin
    Capybara.default_wait_time =2
	if page.has_xpath?('(//label[text()="'"#{field_name}"'"]/ancestor::td[1]/following-sibling::td[1]//*[self::select or self::input])[1]')
      writeFailure"The - #{field_name} - is present over account detail page with -WR- permission"
    elsif page.has_xpath?('//label[text()="'"#{field_name}"'"]')
      writeFailure"The - #{field_name} - is present over account detail page with -R- permission"
    elsif page.has_xpath?('//td[text()="'"#{field_name}"'"]')
      writeFailure"The - #{field_name} - is present over account detail page with -R- permission"
    else
      puts "The - #{field_name} - is -NOT- present over account detail page"
    end
    #end
    Capybara.default_wait_time =30
  end
end


# Verify if the field is appearing as lookup field
Then(/^I should see "([^"]*)" as lookup field$/) do |field_name|

  #step 'I click Edit button from top button row'
  sleep 5
  Capybara.default_wait_time =1
  if page.has_xpath?('//label[text()="'"#{field_name}"'"]/ancestor::td[1]/following-sibling::td[1]//input[@type="text" and @maxlength]/following-sibling::a//img[@class="lookupIcon"]')
    puts "The field  - #{field_name} - is present as - Lookup - field"
  elsif page.has_xpath?('//td[text()="'"#{field_name}"'"]')
    writeFailure "The field  - #{field_name} - is present with - R - permission"
  else
    writeFailure "The field  - #{field_name} - is - NOT - present as a - Lookup - field"

  end
  #step 'I click Save button from top button row'
  Capybara.default_wait_time =30
end