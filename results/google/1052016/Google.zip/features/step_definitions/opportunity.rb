
Then(/^I search "([^"]*)" in search box$/) do |value|
    fill_in "phSearchInput",:with => value
    sleep 5
    find(:xpath,"//*[@id='phSearchButton']").click
    sleep 5
end

Then(/^I click on underlying opportunity in search page$/) do
    within('.pbBody') do
    table=all("tbody")[0]
    table.all('tr')[1].all('th')[0].find('a').click
  end
end

When(/^I double click on renewal status field and verify picklist values$/) do
  sleep 3
  element = page.find(:xpath,"//*[@id='00N3600000PVO7F_ilecell']")
  page.driver.browser.mouse.double_click(element.native)
  sleep 3
  actualvalues =find(:xpath,"//*[@id='00N3600000PVO7F']").all('option').collect(&:text)
  puts "actual values =  #{actualvalues}"
  expectedvalues = ["--None--", "Open", "CS - Backdated - BKD", "CS - Co-term Long - CTL", "CS - Co-term Short - CTS", "CS - Discount - DIS", "CS - Multi-year Advance - MYA", "CS - Pricing Change - PRC", "CS - Re-Cert Fee Included - RCT", "CS - Renewed at Par - R@P", "CS - Service Downgrade - DNG", "CS - Service Upgrade - UPG", "CS - Uncovered - UNC", "NS - Client Product Replacement - PTR", "NS - Competitive DVAR - SCV", "NS - Competitive Product Replacement - PCP", "NS- Competitive Service Loss Other - SCS", "NS - Customer Cost-Benefit Decision -SCB", "NS - Customer No Longer Exists - RNE", "NS - Customer Satisfaction Driven - SSD", "NS - End of Service Life - PEL", "NS - Other Data Management - RDM", "NS - Product Decommissioned - PPD", "NS - Third Party Maintenance - SPM", "NS -Unresponsive End User - REU", "NS - Unresponsive VAR - RUV", "NS - VAR No Service - RVN", "HA - Bad Data - BDT", "HA - Cancelled - CNL", "HA - Covered - COV", "HA - Duplicate - DUP", "HA - End Of Support - EOL", "HA - Evergreen Billing - EVG", "HA - International - INT", "HA - Lease - LEA", "HA - OEM Customer - OEM", "HA - Other - OTH", "HA - Product Return - PRT", "HA - Sales Pull Back - SPB", "<none>", "CS - Downgrade - DNG", "CS - Mid-Term Upgrade - UPG", "CS - SKU Price Decrease - PRC", "CS - Upsell - SPU", "HA - Dev Kit - DVK", "HA - GME/Google Earth Cancellation - GEC", "HA - New Business Closure - NBC", "HA - Non-Renewable Asset - NRA", "NS - Billing Issues – CBI", "NS - Competitor Loss - Cost/Price -RLC", "NS - Competitor Loss - Features - PBF", "NS - Competitor Loss - No Reason - LNR", "NS - Customer Care Issue - CCI", "NS - Data/Location/Security/Privacy- DLP", "NS - Dead-No Decision - DND", "NS - End of Life - Project - PEL", "NS - Move & Migration - MAM", "NS - Moved to Free Version - MFV", "NS - No Budget -CBB", "NS - Other - OTH"]
  puts "expected values = #{expectedvalues}"
  if actualvalues == expectedvalues
    puts "expected values are visible in renewal status field"
  else
    writeFailure "expected values are not visible in renewal status field"
  end
end

Then(/^I fill all mandantory fields to create a new opportunity$/) do
  $newopportunity="smoke-test-us-003690-opportunity-" + Random.new.rand(0001..10000).to_s
  puts $newopportunity
  fill_in "Opportunity Name",:with => $newopportunity
  sleep 3

  # to click on account
  main = page.driver.browser.window_handles.first
  find(:xpath,".//*[@id='opp4_lkwgt']/img").click
  sleep 5
  page.driver.browser.switch_to.window(page.driver.browser.window_handles.last)
  lookup = page.driver.browser.window_handles.last
  page.driver.browser.switch_to.frame("searchFrame")
  fill_in("lksrch",:with=> "smoke-test")
  sleep 5
  find_button('Go!').click
  sleep 4
  page.driver.browser.switch_to.window(lookup)
  page.driver.browser.switch_to.frame("resultsFrame")
  within('.pbBody') do
    table=all("tbody")[0]
    table.all('tr')[1].all('th')[0].find('a').click
  end
  page.driver.browser.switch_to.window(main)
  sleep 10

  fill_in "Close Date",:with => "9/27/2016"
  sleep 2
  select("Not Contacted", :from => 'opp11')
  sleep 2
  select("Volume", :from => 'Opportunity Type')
  select("Direct", :from => 'Direct/Channel')
  select("ANZ", :from => 'Client Region')
  select("United Kingdom", :from => 'Country')
  select("NALA", :from => 'SSI Theatre')
  sleep 2

  # to select price book
  main = page.driver.browser.window_handles.first
  puts "selecting pricebook"
  find(:xpath,".//*[@id='Pricebook2_lkwgt']").click
  sleep 5
  page.driver.browser.switch_to.window(page.driver.browser.window_handles.last)
  lookup = page.driver.browser.window_handles.last
  page.driver.browser.switch_to.frame("searchFrame")
  fill_in("lksrch",:with=> "*")
  sleep 5
  find_button('Go!').click
  sleep 4
  page.driver.browser.switch_to.window(lookup)
  page.driver.browser.switch_to.frame("resultsFrame")
  within('.pbBody') do
    table=all("tbody")[0]
    table.all('tr')[1].all('th')[0].find('a').click
  end
  page.driver.browser.switch_to.window(main)
  sleep 10
end

When(/^I fill all mandantory fields to create a new opportunity for salesops$/) do
  $newopportunity="smoke-test-opportunity" + Random.new.rand(0001..10000).to_s
  puts $newopportunity
  fill_in "Opportunity Name",:with => $newopportunity
  sleep 3

  # to click on account
  main = page.driver.browser.window_handles.first
  find(:xpath,".//*[@id='opp4_lkwgt']/img").click
  sleep 5
  page.driver.browser.switch_to.window(page.driver.browser.window_handles.last)
  lookup = page.driver.browser.window_handles.last
  page.driver.browser.switch_to.frame("searchFrame")
  fill_in("lksrch",:with=> "smoke-test")
  sleep 5
  find_button('Go!').click
  sleep 4
  page.driver.browser.switch_to.window(lookup)
  page.driver.browser.switch_to.frame("resultsFrame")
  within('.pbBody') do
    table=all("tbody")[0]
    table.all('tr')[1].all('th')[0].find('a').click
  end
  page.driver.browser.switch_to.window(main)
  sleep 10

  fill_in "Close Date",:with => "9/27/2016"
  sleep 2
  select("Not Contacted", :from => 'opp11')
  sleep 2
#  select("Volume", :from => 'Opportunity Type')
#  select("Direct", :from => 'Direct/Channel')
#  select("ANZ", :from => 'Client Region')
#  select("United Kingdom", :from => 'Country')
#  select("NALA", :from => 'SSI Theatre')
#  sleep 2

#  # to select price book
#  main = page.driver.browser.window_handles.first
#  puts "selecting pricebook"
#  find(:xpath,".//*[@id='Pricebook2_lkwgt']").click
#  sleep 5
#  page.driver.browser.switch_to.window(page.driver.browser.window_handles.last)
#  lookup = page.driver.browser.window_handles.last
#  page.driver.browser.switch_to.frame("searchFrame")
#  fill_in("lksrch",:with=> "*")
#  sleep 5
#  find_button('Go!').click
#  sleep 4
#  page.driver.browser.switch_to.window(lookup)
#  page.driver.browser.switch_to.frame("resultsFrame")
#  within('.pbBody') do
#    table=all("tbody")[0]
#    table.all('tr')[1].all('th')[0].find('a').click
#  end
#  page.driver.browser.switch_to.window(main)
#  sleep 10
end


Then(/^I should see direct channel field under partner information$/) do
  if page.has_field?("Direct/Channel")
    puts "direct channel field is visible"
  else
    writeFailure "direct channel field is not found"
  end
end

Then(/^I should see Google SFDC ID field under opportunity detail$/) do
  if page.has_content?("Google SFDC ID")
    puts "Google SFDC ID field is visible"
  else
    writeFailure "Google SFDC ID field is not found"
  end
end

When(/^I click on underlying opportunity name$/) do
  sleep 3
  within('.x-grid3-body') do
    table=all("tbody")[0]
    table.all('tr')[0].all('td')[1].all('a')[0].click
    puts "opportunity is selected"
  end
end

When(/^I click on opportunity link under renewal relationship details$/) do
  find(:xpath,".//*[@id='CF00N3600000PVO7I_ilecell']/div/a").click
  sleep 5
end

Then(/^I should see Existing Product field in opportunity edit page$/) do
  if page.has_content?("Existing Product")
    puts "Existing Product field is visible"
  else
    writeFailure "Existing Product field is not found"
  end
end

When(/^I click on new quote button$/) do
  find(:xpath,"//input[@value='New Quote']").click
  sleep 5
end

When(/^I fill quote name under quote information section$/) do
  $newquote="smoke-test-quote" + Random.new.rand(0001..10000).to_s
  puts $newquote
  fill_in "Quote Name",:with => $newquote
  sleep 5
end

When(/^I click on opporunity name under quote detail$/) do
  find(:xpath,".//*[@id='Opportunity_ilecell']/div/a").click
  sleep 5
end

When(/^I select "([^"]*)" from stage picklist$/) do |value|
  select("Closed Sale", :from => 'opp11')
end

When(/^I select quote type under quote information$/) do
   select("Direct", :from => '00N3600000PVaKD')
   sleep 3
end

When(/^I select quote type year under quote information$/) do
  select("3", :from => '00N3600000PVaKC')
  sleep 3
end


When(/^I select "([^"]*)" from view picklist$/) do |value|
  sleep 5
  select value, :from => "View:"
  if find(:button,"Go!").visible? == true
    click_on "Go!"
    sleep 5
  else
    puts "Go! button is not visible"
  end
end

Then(/^I should see Covered Product field in opportunity edit page$/) do
  if page.has_content?("Covered Product")
    puts "Covered Product field is visible"
  else
    writeFailure "Covered Product field is not found"
  end
end

Then(/^I should see Product field in opportunity edit page$/) do
  if page.has_field?("Product")
    puts "Product field is visible"
  else
    writeFailure "Product field is not found"
  end
end

Then(/^I should see Original Order Number under order information$/) do
  if page.has_field?("Original Order Number")
    puts "Original Order Number field is visible"
  else
    writeFailure "Original Order Number field is not found"
  end
end

Then(/^I should verify direct channel field permission$/) do
  if page.has_select?("*Direct/Channel", :selected => "--None--")
    puts "direct channel field is editable picklist"
  else
    puts "direct channel field is not picklist"
  end
end

Then(/^I should verify Google SFDC ID field permission$/) do
  if page.has_content?("Google SFDC ID")
    puts "Google SFDC ID field with read only permission"
  else
    writeFailure "Google SFDC ID field is not visible"
  end
end

When(/^I click on new renewable line item button$/) do
  find(:xpath,"//input[@value='New Renewable Line Item']").click
  sleep 5
end

Then(/^I should verify Original Order Number field permission$/) do
  if page.has_field?("Original Order Number")
    puts "Original Order Number is a text field"
  else
    writeFailure "Original Order Number field is not found"
  end
end

Then(/^I should verify business line picklist values$/) do
  actualvalues =find_field("Business Line").all('option').collect(&:text)
  puts "actual values =  #{actualvalues}"
  expectedvalues = ["--None--", "Maps"]
  puts "expected values = #{expectedvalues}"
  if actualvalues == expectedvalues
    puts "expected values are visible in business line picklist"
  else
    writeFailure "expected values are not visible in business line picklist"
  end
end

Then(/^I should verify Client Territory picklist values$/) do
  actualvalues =find_field("Client Territory").all('option').collect(&:text)
  puts "actual values =  #{actualvalues}"
  expectedvalues = ["--None--", "TBD"]
  puts "expected values = #{expectedvalues}"
  if actualvalues == expectedvalues
    puts "expected values are visible in Client Territory picklist"
  else
    writeFailure "expected values are not visible in Client Territory picklist"
  end
end

Then(/^I should verify Renewal Currencies picklist values$/) do
  actualvalues =find_field("Opportunity Currency").all('option').collect(&:text)
  puts "actual values =  #{actualvalues}"
  expectedvalues = ["EUR - Euro","GBP - British Pound", "JPY - Japanese Yen","USD - U.S. Dollar"]
  puts "expected values = #{expectedvalues}"
  if actualvalues == expectedvalues
    puts "expected values are visible in Renewal Currencies picklist"
  else
    writeFailure "expected values are not visible in Renewal Currencies picklist"
  end
end

Then(/^I should verify SSI Theatre picklist values$/) do
  actualvalues =find_field("SSI Theatre").all('option').collect(&:text)
  puts "actual values =  #{actualvalues}"
  expectedvalues = ["--None--","APAC","EMEA", "NALA"]
  puts "expected values = #{expectedvalues}"
  if actualvalues == expectedvalues
    puts "expected values are visible in SSI Theatre picklist"
  else
    writeFailure "expected values are not visible in SSI Theatre picklist"
  end
end

Then(/^I should verify Client Regions picklist values$/) do
  actualvalues =find_field("Client Region").all('option').collect(&:text)
  puts "actual values =  #{actualvalues}"
  expectedvalues = ["--None--","ANZ","ASIA", "Canada","Commercial","EMEA","EMEA - DACH","EMEA - FRITES","EMEA - Other","EMEA - UK","Federal","Japan","LATAM","MIDDLE EAST - UNITED ARAB EMIRATES","NA","Other APAC","SLED","UK&I - UNITED KINGDOM"]
  puts "expected values = #{expectedvalues}"
  if actualvalues == expectedvalues
    puts "expected values are visible in Client Regions picklist"
  else
    writeFailure "expected values are not visible in Client Regions picklist"
  end
end

When(/^I fill all mandantory fields to create new renewable line item$/) do
  fill_in "Existing Start Date",:with => "9/27/2016"
  sleep 3
  fill_in "New Start Date",:with => "9/27/2016"
  sleep 3
  fill_in "Existing End Date",:with => "9/27/2016"
  sleep 3
  fill_in "New End Date",:with => "9/27/2016"
  sleep 3
  fill_in "Quantity",:with => "200"
  sleep 3

  # to select existing product
  main = page.driver.browser.window_handles.first
  find(:xpath,".//*[@id='j_id0:theFrm:pageBlockId:j_id29:j_id30:0:j_id31_lkwgt']/img").click
  sleep 5
  page.driver.browser.switch_to.window(page.driver.browser.window_handles.last)
  lookup = page.driver.browser.window_handles.last
  page.driver.browser.switch_to.frame("searchFrame")
  fill_in("lksrch",:with=> "smoke-test")
  sleep 5
  find_button('Go!').click
  sleep 4
  page.driver.browser.switch_to.window(lookup)
  page.driver.browser.switch_to.frame("resultsFrame")
  within('.pbBody') do
    table=all("tbody")[0]
    table.all('tr')[1].all('th')[0].find('a').click
  end
  page.driver.browser.switch_to.window(main)
  sleep 10

  # to select owner
  main = page.driver.browser.window_handles.first
  find(:xpath,".//*[@id='j_id0:theFrm:pageBlockId:j_id29:j_id30:11:j_id31_lkwgt']/img").click
  sleep 5
  page.driver.browser.switch_to.window(page.driver.browser.window_handles.last)
  lookup = page.driver.browser.window_handles.last
  page.driver.browser.switch_to.frame("searchFrame")
  fill_in("lksrch",:with=> "*")
  sleep 5
  find_button('Go!').click
  sleep 4
  page.driver.browser.switch_to.window(lookup)
  page.driver.browser.switch_to.frame("resultsFrame")
  within('.pbBody') do
    table=all("tbody")[0]
    table.all('tr')[1].all('th')[0].find('a').click
  end
  page.driver.browser.switch_to.window(main)
  sleep 20
end

Then(/^I should see renewal status field$/) do
  if page.has_content?("Renewal Status")
    puts "renewal status field is visible"
  else
    writeFailure "renewal status field is not visible"
  end
end
