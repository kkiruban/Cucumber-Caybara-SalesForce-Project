Given(/^I click on username in the top right corner then select setup$/) do
  sleep 4
  page.find(:id, "userNavLabel").click
  sleep 10
  within all('.mbrMenuItems')[0] do
    click_on 'Setup'
    sleep 2
  end
end

When(/^I expand "([^"]*)" from administration setup$/) do |arg1|
  sleep 3
  click_on arg1
  sleep 2
end

When(/^I click "([^"]*)" link$/) do |arg1|
  sleep 3
  click_on arg1
  sleep 2
end

When(/^I verify nala time zone and Business Hours$/) do
#  expected_time_zone = "(GMT-05:00) Central Daylight Time (America/Chicago)".to_s
  within('.pbSubsection') do
    table = all("tbody")[0]
    sleep 2
#		actual_time_zone = table.all('tr')[0].all('td')[3].text.to_s
#    puts "Expectes Time Zone: #{expected_time_zone}"
#    puts "Actual Time Zone: #{actual_time_zone}"
#    if expected_time_zone == actual_time_zone
#      puts "Expectes Time Zone value and Actual Time Zone value are equal"
#      puts "Time Zone is verified"
#    else
#      writeFailure "Expectes Time Zone value and Actual Time Zone value are not equal"
#    end

    expected_sunday_value = "No Hours"
    actual_sunday_value = table.all('tr')[1].all('td')[1].all('tr')[0].all('td')[1].text
    puts "Expected sunday value: #{expected_sunday_value}"
    puts "Actual sunday value: #{actual_sunday_value}"
    if expected_sunday_value == actual_sunday_value
      puts "Expectes Business Hours for Sunday and Actual Business Hours for Sunday are equal"
      puts "Business Hours for Sunday is verified"
    else
      writeFailure "Expectes Business Hours for Sunday and Actual Business Hours for Sunday are not equal"
    end

    expected_monday_value = "8:00 AM to 12:00 AM".to_s
    actual_monday_value_1 = table.all('tr')[1].all('td')[1].all('tr')[1].all('td')[1].text.to_s
    actual_monday_value_2 = table.all('tr')[1].all('td')[1].all('tr')[1].all('td')[2].text.to_s
    actual_monday_value_3 = table.all('tr')[1].all('td')[1].all('tr')[1].all('td')[3].text.to_s
#    puts actual_monday_value_1
#    puts actual_monday_value_2
#    puts actual_monday_value_3
    actual_monday_value = actual_monday_value_1 + " " + actual_monday_value_2+ " " + actual_monday_value_3
    actual_monday_value = actual_monday_value.to_s
    puts "Expected monday value: #{expected_monday_value}"
    puts "Actual monday value: #{actual_monday_value}"
    if expected_monday_value == actual_monday_value
      puts "Expectes Business Hours for Monday and Actual Business Hours for Monday are equal"
      puts "Business Hours for Monday is verified"
    else
      writeFailure "Expectes Business Hours for Monday and Actual Business Hours for Monday are not equal"
    end

    expected_tuesday_value = "24 Hours"
    actual_tuesday_value = table.all('tr')[1].all('td')[1].all('tr')[2].all('td')[1].text.to_s
    puts "Expected tuesday value: #{expected_tuesday_value}"
    puts "Actual tuesday value: #{actual_tuesday_value}"
    if expected_tuesday_value == actual_tuesday_value
      puts "Expectes Business Hours for Tuesday and Actual Business Hours for Tuesday are equal"
      puts "Business Hours for Tuesday is verified"
    else
      writeFailure "Expectes Business Hours for Tuesday and Actual Business Hours for Tuesday are not equal"
    end

    expected_wednesday_value = "24 Hours"
    actual_wednesday_value = table.all('tr')[1].all('td')[1].all('tr')[3].all('td')[1].text.to_s
    puts "Expected Wednesday value: #{expected_wednesday_value}"
    puts "Actual Wednesday value: #{actual_wednesday_value}"
    if expected_wednesday_value == actual_wednesday_value
      puts "Expectes Business Hours for Wednesday and Actual Business Hours for Wednesday are equal"
      puts "Business Hours for Wednesday is verified"
    else
      writeFailure "Expectes Business Hours for Wednesday and Actual Business Hours for Wednesday are not equal"
    end

    expected_thursday_value = "24 Hours"
    actual_thursday_value = table.all('tr')[1].all('td')[1].all('tr')[4].all('td')[1].text.to_s
    puts "Expected Thursday value: #{expected_thursday_value}"
    puts "Actual Thursday value: #{actual_thursday_value}"
    if expected_thursday_value == actual_thursday_value
      puts "Expectes Business Hours for Thursday and Actual Business Hours for Thursday are equal"
      puts "Business Hours for Thursday is verified"
    else
      writeFailure "Expectes Business Hours for Thursday and Actual Business Hours for Thursday are not equal"
    end

    expected_friday_value = "12:00 AM to 5:00 PM".to_s
    actual_friday_value_1 = table.all('tr')[1].all('td')[1].all('tr')[5].all('td')[1].text.to_s
    actual_friday_value_2 = table.all('tr')[1].all('td')[1].all('tr')[5].all('td')[2].text.to_s
    actual_friday_value_3 = table.all('tr')[1].all('td')[1].all('tr')[5].all('td')[3].text.to_s
#    puts actual_friday_value_1
#    puts actual_friday_value_2
#    puts actual_friday_value_3
    actual_friday_value = actual_friday_value_1 + " " + actual_friday_value_2+ " " + actual_friday_value_3
    actual_friday_value = actual_friday_value.to_s
    puts "Expected monday value: #{expected_friday_value}"
    puts "Actual monday value: #{actual_friday_value}"
    if expected_friday_value == actual_friday_value
      puts "Expectes Business Hours for Friday and Actual Business Hours for Friday are equal"
      puts "Business Hours for Friday is verified"
    else
      writeFailure "Expectes Business Hours for Friday and Actual Business Hours for Friday are not equal"
    end

    expected_saturday_value = "No Hours"
    actual_saturday_value = table.all('tr')[1].all('td')[1].all('tr')[6].all('td')[1].text
    puts "Expected saturday value: #{expected_saturday_value}"
    puts "Actual saturday value: #{actual_saturday_value}"
    if expected_saturday_value == actual_saturday_value
      puts "Expectes Business Hours for Saturday and Actual Business Hours for Saturday are equal"
      puts "Business Hours for Saturday is verified"
    else
      writeFailure "Expectes Business Hours for Saturday and Actual Business Hours for Saturday are not equal"
    end
  end
end